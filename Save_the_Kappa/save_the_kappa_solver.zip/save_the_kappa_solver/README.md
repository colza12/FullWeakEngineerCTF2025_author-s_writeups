# 環境変数（ctfサーバの出力をそのままセット）
export RPC_URL="http://127.0.0.1:8545"
export BANK_ADDR="0x...  # VulnerableBank"
export PLAYER_PRIV="0x..."  # Player PRIV（

# 任意: デポジット額（Ether, 既定 0.2）
export STAKE_ETH="0.2"

# 実行
python3 solver.py